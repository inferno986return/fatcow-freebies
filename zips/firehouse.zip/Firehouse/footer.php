	<hr id="clear" />
	
	</div>
	


<div id="footer">
	<div id="footer_text">
		&copy; Copyright 2008 Firehou.se  All Rights Reserved. FatCow <a href="http://www.fatcow.com">Web Hosting</a>.
	</div>

	<div id="menu_footer">
			<ul>
				<li><a href="<?php bloginfo('url'); ?>">Home Page</a></li>
				<?php wp_list_pages('depth=1&title_li='); ?>
			</ul>
		</div>

</div>
</body>
</html>