<?php
if ( function_exists('register_sidebar') )
register_sidebar(array('name'=>'sidebar1',
));

register_sidebar(array('name'=>'about_area',
));
?>