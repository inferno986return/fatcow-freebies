
<div class="the_fire_category">

	<img src="<?php bloginfo('stylesheet_directory'); ?>/images/small_fire.jpg" border="0" alt="The Fire Category" align="left" />

	<span class="cat_specific_text">Filed in the Fire Category:</span><br />
	<h2>
		<a href="<?php the_permalink() ?>" rel="bookmark" title="Permanent Link to <?php the_title(); ?>"><?php the_title(); ?></a>
	</h2>
		<small>Posted by <?php the_author() ?> on <?php the_time('F jS, Y') ?>  </small>

</div>